package kr.co.uniquantum.ui.views.search;

public class SearchModeEnum {
	static final public int SEARCH_MODE_NONE 	= 0;
	static final public int SEARCH_MODE_DONG 	= 1;
	static final public int SEARCH_MODE_ROAD 	= 2;
	static final public int SEARCH_MODE_APT 	= 3;
	static final public int SEARCH_MODE_POI		= 4;
}
