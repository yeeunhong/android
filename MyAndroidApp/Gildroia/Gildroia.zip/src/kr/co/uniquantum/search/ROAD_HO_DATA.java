package kr.co.uniquantum.search;

public class ROAD_HO_DATA {
	public short ho;
	public short old_bunji;
	public short old_ho;
	public long  x;
	public long  y;
	
	public String old_dongName;
}
