package kr.co.uniquantum.search;

public class SIGUNGU_DATA {
	String name;
	
	public short 	code;
	public long		road_ofs;
	public long 	offset;
}
