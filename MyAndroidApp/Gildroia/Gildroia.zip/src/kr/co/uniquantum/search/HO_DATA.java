package kr.co.uniquantum.search;

public class HO_DATA {
	public short	ho;
	public long		x;
	public long		y;
}
