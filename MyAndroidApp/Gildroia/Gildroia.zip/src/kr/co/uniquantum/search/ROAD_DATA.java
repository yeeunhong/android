package kr.co.uniquantum.search;

public class ROAD_DATA {
	public String	name;
	public int 		code;
	public short	bunji_cnt;
	public long		offset;
}
