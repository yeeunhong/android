package kr.co.uniquantum.search;

public class SIDO_DATA {
	public byte idx;
	public byte code;
	public short mesh_x_min, mesh_x_max;
	public short mesh_y_min, mesh_y_max;
}
