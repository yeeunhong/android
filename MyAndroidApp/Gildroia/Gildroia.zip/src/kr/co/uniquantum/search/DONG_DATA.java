package kr.co.uniquantum.search;

public class DONG_DATA {
	public String	name;
	public int		code;
	public int		min_x, min_y;
	public boolean	ldong_flag;
	public short	bunji_cnt;
	public long 	offset;
}
