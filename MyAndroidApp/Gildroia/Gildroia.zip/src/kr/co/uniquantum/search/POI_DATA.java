package kr.co.uniquantum.search;

public class POI_DATA 
{
	public String sidoName;
	public String sigunguName;
	public String dongName;
	public String branchName;
	public String call_number;
	
	public boolean catePoi;
	public boolean san;
	public boolean parking;
	public short bunji;
	public short ho;
	public long  x;
	public long  y;
	public long	 route_x;
	public long	 route_y;
}
